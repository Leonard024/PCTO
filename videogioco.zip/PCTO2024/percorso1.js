let bg;
let bgLeft = 0;
let moveSpeed = 8;
let p;
let pers;
let persMovimento;
let ostacolo;
let obstacles = [];
let isPaused = false;
let jumpHeight = 150;

let riparti = false;
let imgFinita = false;

let lastImageChange = 0; // Variable to store the time of the last image change
let imageInterval = 250; // Interval between image changes (0.25 second)

let contF=0;

function preload(){
  bg = loadImage("./img/bg.png");
  pers = loadImage("./img/omino1.png");
  persMovimento = loadImage("./img/omino3.png");
  ostacolo = loadImage("./img/ostacolo.png");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  rectMode(CENTER);
  
  p = new Puck();
  obstacles.push(new Obstacle());
  
  localStorage.setItem("contF", contF);
  
  contF++;
}


function draw() {
  background(220);
  image(bg, bgLeft, 0);
  
  moveBackgroundLeft();
  
  controllaImgFinita();
  
  p.show();
  p.update();
  
  // Check if it's time to change the character image
  if (!isPaused && millis() - lastImageChange > imageInterval) {
    p.toggleImage(); // Toggle between character images
    lastImageChange = millis(); // Update the time of the last image change
  }

  for (let i = obstacles.length - 1; i >= 0; i--){
    if (!isPaused) {
      obstacles[i].move();
      
      //p.jump();
    }
    obstacles[i].show();
    
    if (obstacles[i].isOffScreen()){
      obstacles.splice(i, 1);      
      if (!imgFinita) {
        obstacles.push(new Obstacle());
      }
    }
    
    if (p.x + 95 > obstacles[i].x && p.x < obstacles[i].x + 95) {
      
      window.location.href = 'figura2.html';
      isPaused = true;
      riparti = true;
    }
  }
}

//window.open('nuova_pagina.html', '_blank');

function moveBackgroundLeft(){
  let minBgLeft = -bg.width + width;
  
  if (bgLeft - moveSpeed > minBgLeft && !isPaused){
    bgLeft -= moveSpeed;
  }
}

function controllaImgFinita(){
  if (bgLeft <= -bg.width + width) {  
    imgFinita = true;
  }
}

function keyPressed() {
  if (keyCode === 32) {
    if (isPaused) {
      isPaused = false;
    } else {
      isPaused = true;
      riparti = false;
      p.jump();        
    }
  }
}