let img;

function preload(){
    img= loadImage("img/gameover.png");
    
}
  
function setup() {
    createCanvas(windowWidth, windowHeight);
    
}
  
  
function draw() {

    background(img);

}