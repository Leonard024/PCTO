class Puck {
  constructor(){
    this.x = width / 2 - 350;
    this.y = 420;
    this.speed = moveSpeed;
    this.gravity = 2;
    this.lift = -30;
    this.velocity = 0;
    this.currentImage = pers; // Initially set to the still image
    this.alternateImage = persMovimento; // Image to alternate
  }
  
  jump(){
    this.velocity += this.lift;
  }

  update(){
    this.velocity += this.gravity;
    this.y += this.velocity;

    if (this.y > 420) {
      this.y = 420;
      this.velocity = 0;
    }
  }
  
  toggleImage(){
    // Swap between current image and alternate image
    let temp = this.currentImage;
    this.currentImage = this.alternateImage;
    this.alternateImage = temp;
  }

  show(){
    image(this.currentImage, this.x, this.y, 95, 150);
  }
}