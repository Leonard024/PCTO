// In class Example
// Training a hand pose classification model
// https://github.com/ml5js/Intro-ML-Arts-IMA-F21
// Definizione di una classe Line

// HandPose Model and video


let handpose;
let video;

// Just using two finger points
let thumbX, thumbY;
let indexX, indexY;
let prevIndexX, prevIndexY;

let drawingCanvas; // Canvas per il disegno

let resultP;

let brain;


// Creazione di un oggetto Line
let myLine;

let circleX = 300 ; // Coordinata x del cerchio con il numero 1
let circleY = 40;   // Coordinata y del cerchio con il numero 1
let circleRadius = 15; // Diametro del cerchio con il numero 1

let cont=0;

let imageModelURL = 'https://teachablemachine.withgoogle.com/models/OKVmzeLd9/';

let contFigura = 0;

let totalDistance = 0;
let numPairs = 0;
let avgDistance; 

function modelLoaded() {
  console.log("handpose ready");
}

function setup() {
  document.addEventListener('keydown', (e) => { if (e.ctrlKey && e.key === '1') autorefresh.click();})

  createCanvas(windowWidth, windowHeight);

  // Start the video and hide it
  video = createCapture(VIDEO);
  video.size(320, 240);
  video.hide();
  
  // Load the model
  handpose = ml5.handpose(video, modelLoaded);
  
  // Listen to new 'predict' events
  handpose.on("predict", gotPose);
  
  // Crea una seconda canvas per il disegno
  drawingCanvas = createGraphics(windowWidth, windowHeight);
  // Create an ml5 neural network
  let options = {
    task: "classification",
    debug: true
  }
  brain = ml5.neuralNetwork(options);
}


function gotPose(results) {
  
  // If there is a hand
  if (results.length > 0) {
    thumbX = 0.5 * results[0].annotations.thumb[3][0];
    thumbY = 0.5 * results[0].annotations.thumb[3][1];
    indexX = 0.5 * results[0].annotations.indexFinger[3][0];
    indexY = 0.5 * results[0].annotations.indexFinger[3][1];
  }
  // Creazione di un nuovo oggetto Line con le coordinate attuali
  myLine = new Line(prevIndexX + 130, prevIndexY + 15, indexX + 130, indexY + 15);
  //console.log("mano"+indexX, indexY);
  textSize(10);
  fill(0);
  text(indexX, 1350, 50);
  text(indexY, 1350, 70);
  
  if (myLine.collideCircle(circleX, circleY, circleRadius)){
    window.location.href = 'percorso2.html';
  }
}


function draw() {
  // Draw what is going on
  background(255);
  //togliere effetto specchio
  scale(-1, 1);
  translate(-width, 0);
  image(video, 0, 0);
  // fill(255, 0, 0);  //rosso
  // stroke(255);
  // circle(thumbX, thumbY, 16);
  fill(0, 0, 255);  //blu
  stroke(255);
  circle(indexX, indexY, 16);
  
  // Disegna il tracciamento del dito sulla canvas di disegno
  drawingCanvas.stroke(0); // Colore nero
  drawingCanvas.strokeWeight(10); // Spessore della linea
  if (prevIndexX !== undefined && prevIndexY !== undefined) {
   
    scale(3);
    myLine.draw(drawingCanvas);
  }

  // Aggiorna le posizioni precedenti del dito
  prevIndexX = indexX;
  prevIndexY = indexY;

  // Mostra la canvas di disegno sulla canvas principale
  image(drawingCanvas, 0, 0, windowWidth, windowHeight);

  // Use keypresses to collect data
  // 49 is keycode for '1'
  if (keyIsDown(49)) {
    console.log('close');
    let inputs = [indexX, indexY, thumbX, thumbY];
    let target = ['closed'];
    brain.addData(inputs, target);
  // 50 is keycode for '2'
  } else if (keyIsDown(50)) {
    console.log('open');
    let inputs = [indexX, indexY, thumbX, thumbY];
    let target = ['open'];
    brain.addData(inputs, target);  
  }
  scale(-1, 1);
  translate(-width, 0);
  triangolo();
  //calcola();
  
}

function keyPressed() {
  // Train the model when space bar is pressed
  if (key == ' ') {
    brain.normalizeData();
    brain.train({epochs: 15}, finishedTraining);
  } else if (key == 'd') {
    brain.saveData('dan-open-close-data');
  }
}

// Start classification when model is finished training
function finishedTraining() {
  console.log('finished');
  let inputs = [indexX, indexY, thumbX, thumbY];
  brain.classify(inputs, gotResults);
}


// Just log the results of classification
function gotResults(error, results) {
  // console.log(results[0].label);
  resultP.html(results[0].label);
  let inputs = [indexX, indexY, thumbX, thumbY];
  brain.classify(inputs, gotResults);  
}

     noFill();
     stroke(190);
     strokeWeight(10); 
     rect(1250, 50, 180, 180);
     
function triangolo(){
    noFill();
    stroke(190);
    strokeWeight(10); 
    triangle(1350, 50, 1450, 250, 1250, 250);
    let x = 1350; // Posizione x casuale sulla larghezza della canvas
    let y = 50; // Posizione y casuale sull'altezza della canvas
    let diameter = 30 // Diametro casuale tra 20 e 50
    fill(256, 12, 15); // Imposta il colore di riempimento del cerchio
    noStroke(); // Rimuove il contorno del cerchio
    ellipse(x, y, diameter, diameter); // Disegna il cerchio
    fill(255);
    // Posiziona il testo al centro del cerchio
    textAlign(CENTER, CENTER);
    textSize(20);
    // Scrivi il numero casuale all'interno del cerchio
    text(1, x, y);
    x+= 100;
    y+=200;
    fill(256, 12, 15); // Imposta il colore di riempimento del cerchio
    noStroke(); // Rimuove il contorno del cerchio
    ellipse(x, y, diameter, diameter); // Disegna il cerchio
    fill(255);
    // Posiziona il testo al centro del cerchio
    textAlign(CENTER, CENTER);
    textSize(20);
    // Scrivi il numero casuale all'interno del cerchio
    text(2, x, y);
    x-=200;
    fill(256, 12, 15); // Imposta il colore di riempimento del cerchio
    noStroke(); // Rimuove il contorno del cerchio
    ellipse(x, y, diameter, diameter); // Disegna il cerchio
    fill(255);
    // Posiziona il testo al centro del cerchio
    textAlign(CENTER, CENTER);
    textSize(20);
    // Scrivi il numero casuale all'interno del cerchio
    text(3, x, y);
}
// function calcola(){
  
//   length= math.sqrt((indexX - prevIndexX)**2 +(indexY - prevIndexY)**2);
//   console.log("lenght"+ length);
//   for (let i = 0; i < myLine.length - 1; i++){
//     console.log("punti"+punti)

//     for (let j = i + 1; j < myLine.length; j++){
    
//       let d = dist(myLine[i].x, myLine[i].y, 546, 310) - 150;
//       console.log("d"+ d);
//       totalDistance += d;
//       console.log("total distance"+ totalDistance);
//       numPairs++;
//       console.log("num pairs"+ numPairs);
    
//     }
//   }
  
//   avgDistance = totalDistance / numPairs;
//   console.log("risultato"+avgDistance);
// }